const http = require('http');
http.createServer((req, res) => {
  res.writeHead(200, {'Content-Type': 'application/json'});
  res.end(JSON.stringify({status: 'UE5 Live', port: 8080, gamePort: 7777}));
}).listen(8080);
